# CSGO v2 — atualização visual do HUD

## O que foi atualizado
- Barra superior com botões mais legíveis, cantos arredondados, contraste e transparência.
- Placar central com maior destaque para CT/TR e cronômetro.
- Painel inferior com visual tático, melhor separação de vida, colete, armas e munição.
- Indicadores visuais de vida e colete, limitados visualmente entre 0 e 100.
- Controles touch com alvos de toque maiores, bordas mais claras e sombras para separar do cenário.
- Mantidos os callbacks e as ações existentes de tiro, mira, recarga, pulo, agachamento, troca de arma, placar e pausa.

## Verificação
- A transpilação sintática do arquivo `src/components/MatchHud.tsx` foi executada com sucesso.
- O build completo e a checagem de tipos não puderam ser concluídos neste ambiente porque as dependências do projeto não foram instaladas; a instalação excedeu o tempo disponível.
- Recomenda-se testar no navegador em desktop e em celular, especialmente o HUD em telas estreitas e o posicionamento dos controles no Editor de HUD.
